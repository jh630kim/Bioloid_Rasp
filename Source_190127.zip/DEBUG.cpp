#include<stdio.h>
// #include<dos.h>
// #include <conio.h>
#include <stdlib.h>
#include "define.h"
#include "debug.h"
#include <termios.h>
// #include <unistd.h>

// DOS���� ����, �׷��� LINUX������ �ȵǴ� �Լ��� ���� ����.
int kbhit(void)
{
  struct timeval tv;
  fd_set read_fd;
  
  tv.tv_sec=0;
  tv.tv_usec=0;
  FD_ZERO(&read_fd);
  FD_SET(0,&read_fd);
  
  if(select(1, &read_fd, NULL, NULL, &tv) == -1) return 0;
  if(FD_ISSET(0,&read_fd)) return 1;

  return 0;
}

int getch(void)
{
  int ch;
  struct termios buf;
  struct termios save;

   tcgetattr(0, &save);
   buf = save;
   buf.c_lflag &= ~(ICANON|ECHO);
   buf.c_cc[VMIN] = 1;
   buf.c_cc[VTIME] = 0;
   tcsetattr(0, TCSAFLUSH, &buf);
   ch = getchar();
   tcsetattr(0, TCSAFLUSH, &save);
   return ch;
}

int max(int a,int b)
{
  if (a>b) return a;
  else return b;
}

int min(int a, int b)
{
  if (a<b) return a;
  else return b;
}
// �������, Dos �Լ� ����  


void DBG_Print_T(char* Title, const double mtx[3][4])
{
	int i;

	if (Title != NULL)	printf("Title = %s \r\n",Title);

	for (i=0;i<3;i++)
		printf("   %9.4f, %9.4f, %9.4f, %9.4f\r\n",mtx[i][0], mtx[i][1], mtx[i][2],mtx[i][3]);
	getch();
}

void DBG_Print_theta(char* Title, const double theta[6])
{
	if (Title != NULL)	printf("Title = %s \r\n",Title);

	printf("   %9.4f, %9.4f, %9.4f, %9.4f, %9.4f, %9.4f\r\n",theta[0],theta[1],theta[2],theta[3],theta[4],theta[5]);
	getch();
}

void DBG_Print_P(char* Title, const double P[3])
{
	if (Title != NULL)	printf("%s : ",Title);

	printf("Px = %6.1f, Py = %6.1f, Pz = %6.1f\r\n",P[X],P[Y],P[Z]);
}

void DBG_LF(void)
{
	printf("\r\n");
	getch();
}

void DBG_R_default(double mtx[3][4])
{
	mtx[0][3] = -200;
	mtx[1][3] = 0;
	mtx[2][3] = -32.7;
}

void DBG_L_default(double mtx[3][4])
{
	mtx[0][3] = -200;
	mtx[1][3] = 0;
	mtx[2][3] = 32.7;
}

void DBG_Print_Packet(const unsigned char TxData[BUFFER_LENGTH])
{
	int total_length;

	total_length = min(TxData[3]+4,BUFFER_LENGTH);

	for (int i=0;i<total_length;i++)
	{
		printf("[%02X]",TxData[i]);
	}
	printf("\r\n");
}



